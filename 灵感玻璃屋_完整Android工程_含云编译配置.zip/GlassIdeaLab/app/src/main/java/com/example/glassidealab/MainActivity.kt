package com.example.glassidealab

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("glass_ideas", MODE_PRIVATE)
        setContent {
            GlassIdeaApp(
                initialSaved = prefs.getStringSet("saved", emptySet()) ?: emptySet(),
                onSave = { prefs.edit().putStringSet("saved", it.toSet()).apply() }
            )
        }
    }
}

private data class Idea(val category: String, val title: String, val detail: String, val task: String)

private val ideas = listOf(
    Idea("脑洞实验", "给未来的自己写一条语音留言", "假设五年后的你会收到它。现在的你最想提醒未来的自己什么？", "用 30 秒说完，不许删改。"),
    Idea("生活挑战", "今天给一个普通物件拍电影海报", "选一只杯子、一把钥匙或一片叶子，把它拍成主角。", "给它起片名，再写一句宣传语。"),
    Idea("创造力", "设计一种不存在的节日", "它庆祝什么？人们会穿什么、吃什么、做什么？", "给这个节日设计一个专属仪式。"),
    Idea("观察练习", "寻找城市里的隐藏图案", "看看窗户、地砖、树影和云朵，找出一个意外出现的图形。", "拍下来，并给它命名。"),
    Idea("社交灵感", "向朋友提出一个奇怪但温柔的问题", "例如：如果你的心情是一种天气，今天是什么天气？", "认真听完答案，不急着评价。"),
    Idea("微型创作", "写一个只有三句话的悬疑故事", "第一句建立日常，第二句制造异常，第三句彻底反转。", "试着让最后一句不超过十个字。"),
    Idea("数字排毒", "给手机设置一个无屏幕角落", "挑一个小空间，放一本书、一支笔或一件喜欢的小物。", "在这里待十分钟，不碰手机。"),
    Idea("随机探索", "用一条没走过的小路回家", "留意路边的招牌、声音和气味，观察熟悉地方的新一面。", "记下三个之前没注意到的细节。"),
    Idea("审美训练", "用三种颜色记录今天", "选出代表今天的三种颜色，不必解释得很准确。", "为这组三色取一个名字。"),
    Idea("快乐收集", "制作一份微小快乐清单", "记录那些不值得发朋友圈、但确实让你开心的小事。", "今天至少收集五件。")
)

@Composable
fun GlassIdeaApp(initialSaved: Set<String>, onSave: (Set<String>) -> Unit) {
    var current by remember { mutableIntStateOf(0) }
    var saved by remember { mutableStateOf(initialSaved) }
    var showSaved by remember { mutableStateOf(false) }
    val item = ideas[current]
    val bg = Brush.linearGradient(listOf(Color(0xFFE9F2FF), Color(0xFFF7ECFF), Color(0xFFE7FAF7)))

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF5268C9), onSurface = Color(0xFF20243A))) {
        Box(Modifier.fillMaxSize().background(bg)) {
            Box(Modifier.offset(x = (-70).dp, y = 80.dp).size(210.dp).clip(CircleShape).background(Color(0x66A7B8FF)))
            Box(Modifier.align(Alignment.BottomEnd).offset(x = 65.dp, y = 30.dp).size(230.dp).clip(CircleShape).background(Color(0x66B9EDE4)))
            Column(
                Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                    .verticalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("DAILY SPARK", color = Color(0xFF66739B), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Text("灵感玻璃屋", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF20243A))
                    }
                    Surface(shape = CircleShape, color = Color.White.copy(alpha = .55f), border = BorderStroke(1.dp, Color.White)) {
                        IconButton(onClick = { showSaved = !showSaved }) {
                            Icon(Icons.Default.Bookmark, contentDescription = "收藏", tint = Color(0xFF5268C9))
                        }
                    }
                }
                Spacer(Modifier.height(30.dp))
                GlassPanel(Modifier.fillMaxWidth()) {
                    Text(if (showSaved) "你的灵感收藏" else "给今天一点新鲜感", color = Color(0xFF66739B), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(18.dp))
                    if (showSaved) {
                        val savedIdeas = ideas.filter { it.title in saved }
                        if (savedIdeas.isEmpty()) {
                            Text("还没有收藏。遇到喜欢的灵感，点一下书签吧。", fontSize = 16.sp, color = Color(0xFF343A55), lineHeight = 25.sp)
                        } else {
                            savedIdeas.forEach {
                                Text("✦  ${it.title}", color = Color(0xFF303653), fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(vertical = 8.dp))
                                Text(it.detail, color = Color(0xFF737B98), fontSize = 13.sp)
                                Divider(Modifier.padding(vertical = 8.dp), color = Color(0x33747FA3))
                            }
                        }
                    } else {
                        AnimatedContent(targetState = current, label = "idea") { idx ->
                            val idea = ideas[idx]
                            Column {
                                Surface(shape = RoundedCornerShape(50), color = Color(0x1F6579D8)) {
                                    Text(idea.category, modifier = Modifier.padding(horizontal = 13.dp, vertical = 7.dp), color = Color(0xFF5268C9), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(Modifier.height(20.dp))
                                Text(idea.title, fontSize = 26.sp, lineHeight = 35.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF20243A))
                                Spacer(Modifier.height(14.dp))
                                Text(idea.detail, fontSize = 15.sp, lineHeight = 25.sp, color = Color(0xFF626B88))
                                Spacer(Modifier.height(22.dp))
                                Surface(shape = RoundedCornerShape(18.dp), color = Color(0x887F91D8).copy(alpha = .12f)) {
                                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                                        Text("小小行动", color = Color(0xFF5268C9), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Spacer(Modifier.height(6.dp))
                                        Text(idea.task, color = Color(0xFF343A55), fontSize = 14.sp, lineHeight = 22.sp)
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(22.dp))
                if (!showSaved) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(
                            onClick = { val next = (current + 1) % ideas.size; current = next },
                            shape = RoundedCornerShape(18.dp),
                            border = BorderStroke(1.dp, Color.White),
                            colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.White.copy(alpha = .42f)),
                            modifier = Modifier.weight(1f).height(54.dp)
                        ) {
                            Icon(Icons.Default.Refresh, null)
                            Spacer(Modifier.width(8.dp))
                            Text("换一个灵感")
                        }
                        Button(
                            onClick = {
                                val title = item.title
                                saved = if (title in saved) saved - title else saved + title
                                onSave(saved)
                            },
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.size(54.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5268C9))
                        ) {
                            Icon(if (item.title in saved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, null)
                        }
                    }
                    Text("${current + 1} / ${ideas.size}  ·  每一次随机，都是新的开始", color = Color(0xFF7B83A0), fontSize = 11.sp, modifier = Modifier.padding(top = 17.dp))
                } else {
                    TextButton(onClick = { showSaved = false }) { Text("返回灵感卡片") }
                }
                Spacer(Modifier.height(25.dp))
                Text("MAKE A LITTLE MAGIC TODAY", color = Color(0x88717B9C), fontSize = 10.sp, letterSpacing = 2.sp)
            }
        }
    }
}

@Composable
private fun GlassPanel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(30.dp),
        color = Color.White.copy(alpha = .58f),
        border = BorderStroke(1.dp, Color.White.copy(alpha = .9f)),
        shadowElevation = 18.dp
    ) {
        Column(Modifier.padding(24.dp), content = content)
    }
}

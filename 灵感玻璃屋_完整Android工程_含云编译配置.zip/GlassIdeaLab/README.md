# 灵感玻璃屋（Glass Idea Lab）

原生 Android 应用，Kotlin + Jetpack Compose；不是 Flutter 项目。

## 项目参数
- 应用名称：灵感玻璃屋
- applicationId（正式包名）：`com.example.glassidealab`（debug / release 共用）
- minSdk：26（Android 8.0）
- targetSdk / compileSdk：35
- Java：17；Gradle：8.9；Android Gradle Plugin：8.7.3；Kotlin：2.0.21
- 构建类型：debug / release（当前默认交付 debug）
- 权限：不申请网络、存储或 Root 权限

## 已包含
- 完整 Kotlin 源码、Manifest、Gradle Kotlin DSL 配置
- `gradle/wrapper/gradle-wrapper.properties`
- `gradlew`、`gradlew.bat`
- 应用名称、主题、矢量启动图标及 Android 自适应图标
- GitHub Actions 云端构建工作流

## 重要说明：Gradle Wrapper JAR
本压缩包包含 Wrapper 启动脚本和配置，但没有内置 `gradle-wrapper.jar` 二进制文件（当前制作环境无法联网取得官方发行文件）。GitHub Actions 工作流会先用已安装的 Gradle 8.9 执行 `gradle wrapper`，生成官方 Wrapper JAR，再通过 `./gradlew` 编译。因此云端构建流程不依赖 ZIP 内预置的 JAR。

如果在本地已有 Gradle 8.9，可在项目根目录执行：
```bash
gradle wrapper --gradle-version 8.9
./gradlew assembleDebug
```
AndroidIDE 可直接打开项目根目录（`settings.gradle.kts` 所在目录），使用 JDK 17 完成 Gradle Sync 后运行 `:app:assembleDebug`。

## GitHub 手机端云编译
1. GitHub 新建空仓库，例如 `GlassIdeaLab`。
2. 解压 ZIP，把 `GlassIdeaLab` 文件夹里的全部内容上传到仓库根目录，注意 `.github` 隐藏目录也要上传。
3. 打开仓库 Actions → `Build Android APK` → `Run workflow`。
4. 等待工作流完成，打开运行记录底部 Artifacts，下载 `GlassIdeaLab-debug-apk`。
5. 解压 Artifact，安装 `app-debug.apk`。

## APK 输出路径
`app/build/outputs/apk/debug/app-debug.apk`

这是 debug 测试包。release 版本尚未配置发布签名，不能当作已签名商店发行包。
